import React from "react";
import { useDispatch, useSelector } from "react-redux";

const Favourites = () => {
  const dispatch = useDispatch();
  const movies = useSelector((state) => state.favourites.favourites);
  return (
    <div className="bg-gray-800 min-h-screen p-8">
      <ul className="list h-25">
        {movies.map((movie) => (
          <li
            key={movie.id}
            className="relative grid grid-cols-4 gap-x-6 font-serif text-lg items-center py-4 pl-8 border-b border-gray-200"
          >
            <img
              src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`}
              alt={`${movie.title} poster`}
              className="w-full grid-row-span-2"
            />
            <h3 className="text-xl">{movie.title}</h3>
            <div className="flex items-center gap-x-6">
              <p className="flex items-center gap-x-2">
                <span role="img" aria-label="Calendar">
                  🗓
                </span>
                <span>{movie.release_date}</span>
              </p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Favourites;
